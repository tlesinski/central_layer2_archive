SET DEFINE ON
SET SERVEROUTPUT ON
WHENEVER SQLERROR EXIT SQL.SQLCODE

PROMPT Rebuilding mail utility metadata

CONNECT &&ACTIVE_ARCHIVER_SCHEMA/"&&ACTIVE_ARCHIVER_PASSWORD"@&&ACTIVE_ARCHIVER_CONNECT

DECLARE
  l_count PLS_INTEGER;
BEGIN
  SELECT COUNT(*)
    INTO l_count
    FROM USER_TABLES
   WHERE TABLE_NAME = 'TBL_UTIL_CONFIG';

  IF l_count <> 1 THEN
    RAISE_APPLICATION_ERROR(-20430, 'Utility config table is not installed in the configured ARCHIVER schema');
  END IF;
END;
/

MERGE INTO TBL_UTIL_CONFIG t
USING (
  SELECT 'MAIL_ENABLED' config_key, UPPER(TRIM(q'[&&MAIL_ENABLED]')) config_value, 'Enables real SMTP sending when set to Y' config_comment FROM dual UNION ALL
  SELECT 'SMTP_HOST', TRIM(q'[&&MAIL_SMTP_HOST]'), 'SMTP host used by PKG_UTIL_MAIL' FROM dual UNION ALL
  SELECT 'SMTP_PORT', TRIM(q'[&&MAIL_SMTP_PORT]'), 'SMTP port used by PKG_UTIL_MAIL' FROM dual UNION ALL
  SELECT 'MAIL_FROM', TRIM(q'[&&MAIL_FROM]'), 'Default sender address' FROM dual UNION ALL
  SELECT 'MAIL_TO', TRIM(q'[&&MAIL_TO]'), 'Default recipient list' FROM dual
) s
ON (t.CONFIG_KEY = s.CONFIG_KEY)
WHEN MATCHED THEN
  UPDATE SET t.CONFIG_VALUE = s.CONFIG_VALUE,
             t.CONFIG_COMMENT = s.CONFIG_COMMENT,
             t.UPDATED_AT = SYSTIMESTAMP
WHEN NOT MATCHED THEN
  INSERT (CONFIG_KEY, CONFIG_VALUE, CONFIG_COMMENT)
  VALUES (s.CONFIG_KEY, s.CONFIG_VALUE, s.CONFIG_COMMENT);

COMMIT;

PROMPT ARCHIVER mail utility metadata updated

COLUMN replica_mail_seed_script NEW_VALUE REPLICA_MAIL_SEED_SCRIPT NOPRINT

SELECT CASE
         WHEN UPPER('&&ACTIVE_REPLICA_SCHEMA') = UPPER('&&ACTIVE_ARCHIVER_SCHEMA')
          AND '&&ACTIVE_REPLICA_CONNECT' = '&&ACTIVE_ARCHIVER_CONNECT'
         THEN 'skip_mail_seed.sql'
         ELSE 'seed_mail_replica.sql'
       END replica_mail_seed_script
  FROM dual;

@@&&REPLICA_MAIL_SEED_SCRIPT

PROMPT Mail utility metadata rebuild completed
